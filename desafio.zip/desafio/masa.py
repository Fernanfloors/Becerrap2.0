def kilogramos_a_gramos(kilogramo):
    return kilogramo *1000

def gramos_a_kilogramos(gramos):
    return gramos /1000 

if __name__=="__main__":
    kilogramo = 2,5
    gramos= kilogramos_a_gramos(kilogramo)
    print(f"{kilogramo} kilogramos son equivalentes a {gramos} gramos")